import Dup from './assets/tree-logo.jpg';
// import Audio from './assets/--audio-name---';

const Array = [
    {
        "Audio": ""/*Audio */,
        "ImageURL": Dup,
        "Name": "Mango Tree",
        "Area": 22,
        "Age": 12,
        "Height": 22,
        "Latitude": 13.03,
        "Longitude": 12.43,
        "Plantation Year": 2012,
        "Oxygen Released": 12
    },
    {
        "Audio": "",
        "ImageURL": "",
        "Name": "Mango Tree",
        "Area": 22,
        "Age": 12,
        "Height": 22,
        "Latitude": 13.03,
        "Longitude": 12.43,
        "Plantation Year": 2012,
        "Oxygen Released": 12
    },
    {
        "Audio": "",
        "ImageURL": "",
        "Name": "Mango Tree",
        "Area": 22,
        "Age": 12,
        "Height": 22,
        "Latitude": 13.03,
        "Longitude": 12.43,
        "Plantation Year": 2012,
        "Oxygen Released": 12
    },
    {
        "Audio": "",
        "ImageURL": "",
        "Name": "Mango Tree",
        "Area": 22,
        "Age": 12,
        "Height": 22,
        "Latitude": 13.03,
        "Longitude": 12.43,
        "Plantation Year": 2012,
        "Oxygen Released": 12
    },
    {
        "Audio": "",
        "ImageURL": "",
        "Name": "Mango Tree",
        "Area": 22,
        "Age": 12,
        "Height": 22,
        "Latitude": 13.03,
        "Longitude": 12.43,
        "Plantation Year": 2012,
        "Oxygen Released": 12
    }
]

export default Array;